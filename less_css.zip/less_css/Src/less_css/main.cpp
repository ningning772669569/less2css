#include "cstdio"
#include "cstring"
#include "iostream"
#include "algorithm"
#include "vector"
#include "queue"
#include "set"
#include "map"
#include "stack"
#include "utility"
#include "fstream"
#include "cctype"
using namespace std;

typedef long long LL;
typedef pair<string,int>    psi;
typedef pair<string,string> pss;
typedef pair<int,int>       pii;
typedef pair<int,string>    pis;
/**
** 进程节点
**/
struct pro_node{
    string current;
    string prefix;
    string para;

    int from,to;
    pro_node(string current,string prefix,string para,int from,int to):current(current),prefix(prefix),para(para),from(from),to(to){}
    pro_node(){}
};
/**
** 用于存储当前作用下混合用的类
**
**/
struct callnode{
    ///用于存放该类的类名
    string prefix;
    ///用于存放该类的参数
    string para;
    ///用于存放该类的函数体（或者是类体？）
    string funbody;
    ///是否可以直接直接调用
    int state;
    ///1 代表内部变量已经为你全替换成为常量或者内部并没有变量
    ///2 代表内部的变量在当前的作用域下并没有找到，需要去混合方的作用域下寻找

    callnode(string prefix,string para,string funbody,int state):prefix(prefix),para(para),funbody(funbody),state(state){}
    callnode(){}
};
const int maxlen=1000000;

int length;
//char tepcontent[maxlen];
string content;
set<char> oper;
vector< set<pss> > variable;
vector<callnode> fun;
set<pss> curvar;
bool interpolation=0;
FILE *fin,*fout;

int readin(int fileid)
{

    char cur[100];
    char pos1[200];
    char pos2[200];
    memset(pos1,0,sizeof(pos1));
    memset(pos2,0,sizeof(pos2));
    memset(cur,0,sizeof(cur));

    char  pre1[]=".\\less\\test";
    char  pre2[]=".\\css\\test";
    sprintf(cur,"%d.less",fileid);

    strcpy(pos1,pre1);
    strcat(pos1,cur);
    fin=fopen(pos1,"r");
    if(fin==NULL)
        return 0;
    while(!feof(fin)){
        char c;
        c=fgetc(fin);
        content.push_back(c);
    }
    fclose(fin);
    memset(cur,0,sizeof(cur));
    sprintf(cur,"%d.css",fileid);
    strcpy(pos2,pre2);
    strcat(pos2,cur);
    fout=fopen(pos2,"w");
    if(fout==NULL)
        return 0;

    return 1;
}

void substring(char target[],string & s,int from ,int to)
{

    int i=from;
    for(i=from;i<=to;i++){
        target[i-from]=s[i];
    }
    target[i-from]=0;

}

string sub(string &s,int from,int to)
{
    char tep[20000];
    memset(tep,0,sizeof(tep));
    for(int pos=from;pos<=to;pos++)
        tep[pos-from]=s[pos];
    string re(tep);
    return re;
}

/**
***函数功能： 得到句子末尾
**/
int getend(string &content,int from)
{

    string::size_type pos=from;
    while(pos<content.size() && content[pos]!=';')
        pos++;
    return pos;

}

/**
***函数功能： 得到行末尾
**/
int getlend(string &content,int from)
{
    int pos=from;
    while(content[pos] && content[pos]!='\n')
        pos++;
    return pos;

}

/**
***函数功能： 得到块注释的末尾
**/
int anotatnend(string &content,int from)
{
    int pos=from;
    while(!(content[pos]=='*' &&content[pos+1]=='/'))
        pos++;
    return pos+1;
}
/**
**函数功能： 得到与之所对应的大括号
**/
int getmatch(string & content,int from)
{
    int bracketnum=1;
    int pos=from;
    length=content.size();
    while(pos<length && bracketnum){
        pos++;
        if(content[pos]=='{')
            bracketnum++;
        if(content[pos]=='}')
            bracketnum--;
    }
    return pos;

}
int isblank(char c)
{
    int flag=0;
    if(c==' '||c=='\t'||c=='\n')
        flag=1;
    return flag;
}
/**
*** 函数功能：获取分词的标志
**/
int istag(char c)
{
    if(c==';')
        return 1;
    if(c=='{')
        return 1;
    if(c=='/')
        return 1;
    if(c=='}')
        return 1;
    return 0;
}
int invar(char c)
{
    if(c>='0' && c<='9')
        return 1;
    if(c>='a' && c<='z')
        return 1;
    if(c>='A' && c<='Z')
        return 1;
    if(c=='-')
        return 1;
    if(c=='_')
        return 1;
    if(c=='@')
        return 1;
    if(c=='#')
        return 1;
    return 0;

}
/**
*** 函数功能： 获取大括号前面的选择器的前缀
**/
pss getpre(string &content,int from)
{
    pss re;
    char pre[200];
    char para[200];
    memset(para,0,sizeof(para));
    memset(pre,0,sizeof(pre));
    int pos=from-1;
    while(pos>0 && (content[pos]==' '|| content[pos]=='\t'))
        pos--;
    if(content[pos]==')'){
        int teppos=pos-1;
        while(content[teppos]!='(')
                teppos--;
        substring(para,content,teppos+1,pos-1);
        re.second= string(para);
        pos=teppos-1;
        while(content[pos]==' '||content[pos]=='\t')
            pos--;
    }
    else{
        re.second="";
    }

    int tail=pos;
    while(pos>=0 && !isblank(content[pos]))
        pos--;
    int head=pos+1;
    substring(pre,content,head,tail);
    string t(pre);
    re.first=t;
    return re;
}

/**
*** 函数功能 ： 将提取出来的变量插入到当前的变量集中
**/
void insertvar(set<pss> & p,pss s)
{
    //cout<<s.first<<"-----"<<s.second<<endl;
    string tepvar=s.first;
    if(!p.empty()){
        set<pss>::iterator iter=p.begin();
        while(iter!=p.end()){
            if((*iter).first==tepvar){
                p.erase(iter);
                break;
            }
            iter++;
        }
    }
    p.insert(s);

}
int havevar(string &content,int from,int to)
{
    for(int pos=from;pos<=to;pos++){
        if(content[pos]=='@')
            return 1;
    }
    return 0;
}
int haveoper(string &content,int from,int to)
{

    for(int pos=from;pos<=to;pos++){
        if(oper.count(content[pos])){

            return 1;
        }

    }
    return 0;
}
/**
***函数功能 ： 从变量域中取出对应的值（仅限于一重）
**/
string findval(set<pss> &p,string var)
{

    string re;

    bool notfound=true;
    set<pss>::iterator curiter=p.begin();
    while(curiter!=p.end()){

        if((*curiter).first==var){
            re=(*curiter).second;
            notfound=false;
            break;
        }
        curiter++;
    }
    ///这里的variable可能唯恐
    if(!variable.empty()){
    vector<set<pss> >::iterator iter=variable.end();
    iter--;

    while(notfound){

        set<pss>::iterator titer=(*iter).begin();
        while(titer!=(*iter).end()){
            if((*titer).first==var){
                re=(*titer).second;
                notfound=false;
                break;
            }
            else
                titer++;
        }
        ///如果都已经找到最后的位置还是没有找到的话就返回空字符
        if(iter==variable.begin())
            break;
        else
            iter--;
    }
    }

    return re;
}
/**
*** 函数功能： 求出变量的值其中包括多重
**/
string getval(set<pss> &p,string var)
{

    string::size_type pos=0;
    string::size_type tail=var.size()-1;
    while(var[tail]==' '||var[tail]=='\t')
        tail--;
    while(var[pos]=='@')
        pos++;
        pos--;
    string tvar=var.substr(pos,tail-pos+1);

    while(pos>=0){

        tvar=findval(p,tvar);
        ///没有找到变量
        if(tvar=="")
        {
            break;

        }
        if(pos>0)
            tvar="@"+tvar;
        if(pos==0)
            break;
        else
            pos--;

    }
    return tvar;
}

/**
*** 函数功能 ： 将含有变量的式子转化成常量
**/
string var2val(set<pss>&p,string & content,int from,int to)
{
    ///要注意对字符串插值的特判
    string re;
    string equation=sub(content,from,to);
    string::size_type pos=0;
    while(pos < equation.size()){
        if(equation[pos]=='@'){
            if(equation[pos+1]=='{'){

                ///字符串插值走起
                int endpos=pos;
                while(equation[endpos]!='}')
                    endpos++;
                string tepvar="@"+equation.substr(pos+2,endpos-pos-2);
                string val=getval(p,tepvar);
                ///如果没找到
                if(val==""){
                    equation = "";
                    break;
                }
                /// 出去字符串变量引号
                val=val.substr(1,val.size()-2);
                equation.replace(pos,endpos-pos+1,val);
                pos+=val.size();
               interpolation=1;

            }
            else{
                int endpos=pos;
                while(endpos<=to&&invar(equation[endpos]))
                    endpos++;
                string tepvar=equation.substr(pos,endpos-pos);
                string val=getval(p,tepvar);

                ///如果没找到
                if(val==""){
                    equation="";
                    break;
                }

                equation.replace(pos,endpos-pos,val);

                pos+=val.size();
            }
        }
        else
            pos++;
    }
    return equation;

}

/**
** 函数功能 ： 得到相互运算的两个变量的类型
**/
int gettype(string a,string b)
{

    if(a.find('#')!=a.npos||b.find('#')!=b.npos)
        return 1;
    if(a.find("rgb")!=a.npos ||b.find("rgb")!=b.npos)
        return 1;
    if(a.find("px")!=a.npos ||b.find("px")!=b.npos)
        return 2;
    return 3;


}
string add2(string a,string b)
{

    char tepre[20];
    memset(tepre,0,sizeof(tepre));
    ///除掉末尾的px，方便计算
    string tepa=a.substr(0,a.size()-2);
    string tepb=b.substr(0,b.size()-2);
    int num1=atoi(tepa.c_str());
    int num2=atoi(tepb.c_str());
    int num=num1+num2;
    sprintf(tepre,"%dpx",num);
    string re(tepre);
    return re;

}
string subtract2(string a,string b)
{
    char tepre[20];
    memset(tepre,0,sizeof(tepre));
    ///除掉末尾的px
    string tepa=a.substr(0,a.size()-2);
    string tepb=b.substr(0,b.size()-2);
    int num1=atoi(tepa.c_str());
    int num2=atoi(tepb.c_str());
    int num=num1-num2;
    sprintf(tepre,"%dpx",num);
    string re(tepre);
    return re;

}
string division2(string a,string b)
{
    char tepre[30];
    memset(tepre,0,sizeof(tepre));
    string tepa=a.substr(0,a.size()-2);
    int num1=atoi(tepa.c_str());
    int num2=atoi(b.c_str());
    int num=num1/num2;
    sprintf(tepre,"%dpx",num);
    string re(tepre);
    return re;

}
string mul2(string a,string b)
{
    char tepre[30];
    memset(tepre,0,sizeof(tepre));
    string tepa;
    string tepb;
    if(a.find("px")!=a.npos)
        tepa=a.substr(0,a.size()-2);
    else
        tepa=a;
    if(b.find("px")!=b.npos){
        tepb=b.substr(0,b.size()-2);
    }
    else
        tepb=b;
    int num1=atoi(tepa.c_str());
    int num2=atoi(tepb.c_str());
    int num=num1*num2;
    sprintf(tepre,"%dpx",num);
    string re(tepre);
    return re;

}
string change1(string s)
{
    if(s.find('#')==s.npos)
        return s;
    string re;
    string::size_type pos;
    pos=s.find('#');
    int num=0;
    pos++;
    while(pos<s.size()){
        num++;pos++;
    }
    if(num>5)
        return s;
    else{
        pos=s.find('#');
        re.push_back('#');
        for(int i=1;i<=3;i++){
            re.push_back(s[pos+i]);
            re.push_back(s[pos+i]);
        }
    }
    return re;
}
string change2(string s)
{
    return s;

}
string add1(string a,string b)
{
    a=change1(a);b=change1(b);
    map<char,int> decode;
    map<int,char> encode;
    int sum[4];
    char tepre[10];
    memset(tepre,0,sizeof(tepre));
    memset(sum,0,sizeof(sum));
    for(int i=0;i<=9;i++){
        char c=i+'0';
        decode[c]=i;
        encode[i]=c;
    }
    for(int i=0;i<=5;i++){
        char c='a'+i;
        decode[c]=10+i;
        encode[10+i]=c;
    }
    /*
    if(a.size()==4){
        a=change1(a);
    }
    if(b.size()==4)
        b=change1(b);
    if(a.size()>9)
        a=change2(a);
    if(b.size()>9)
        b=change2(b);
    */
    string::size_type pos;
    string tepa,tepb;
    pos=a.find('#');
    tepa=a.substr(pos,7);
    pos=b.find('#');
    tepb=b.substr(pos,7);
    for(int i=1;i<=3;i++){
        sum[i]+=decode[tepa[i*2]];
        sum[i]+=decode[tepb[i*2]];
        sum[i]+=decode[tepa[i*2-1]]*16;
        sum[i]+=decode[tepb[i*2-1]]*16;

    }

    for(int i=1;i<=3;i++){
        if(sum[i]>255){

            sum[i]=255;

        }

    }
    tepre[0]='#';
    for(int i=1;i<=3;i++){
        tepre[i*2-1]=encode[sum[i]/16];
        tepre[i*2]=encode[sum[i]%16];
    }
    string re(tepre);
    return re;

}
string mul1(string a,string b)
{
    a=change1(a);b=change1(b);
    int num;
    string color;
    string::size_type pos=0;
    map<char,int> decode;
    map<int,char> encode;
    int sum[4];
    char tepre[10];
    memset(tepre,0,sizeof(tepre));
    memset(sum,0,sizeof(sum));
    if(a.find('#')!=a.npos){
        num=atoi(b.c_str());
        pos=a.find('#');
        color=a.substr(pos,7);
    }
    else{
        num=atoi(a.c_str());
        pos=b.find('#');
        color=b.substr(pos,7);
    }
    for(int i=0;i<=9;i++){
        char c=i+'0';
        decode[c]=i;
        encode[i]=c;
    }
    for(int i=0;i<=5;i++){
        char c='a'+i;
        decode[c]=10+i;
        encode[10+i]=c;
    }
    for(int i=1;i<=3;i++){
        sum[i]+=decode[color[i*2]]*num;
        sum[i]+=decode[color[i*2-1]]*16*num;
    }
    for(int i=1;i<=3;i++)
        if(sum[i]>255)
            sum[i]=255;
    tepre[0]='#';
    for(int i=1;i<=3;i++){
        tepre[i*2-1]=encode[sum[i]/16];
        tepre[i*2]=encode[sum[i]%16];
    }
    string re(tepre);
    return re;
}
string subtract1(string a,string b)
{
    a=change1(a);b=change1(b);
    //cout<<a<<b<<endl;
    map<char,int> decode;
    map<int,char> encode;
    int sum[4];
    char tepre[10];
    memset(tepre,0,sizeof(tepre));
    memset(sum,0,sizeof(sum));
    for(int i=0;i<=9;i++){
        char c=i+'0';
        decode[c]=i;
        encode[i]=c;
    }
    for(int i=0;i<=5;i++){
        char c='a'+i;
        decode[c]=10+i;
        encode[10+i]=c;
    }

    string::size_type pos;
    string tepa,tepb;
    pos=a.find('#');
    tepa=a.substr(pos,7);
    pos=b.find('#');
    tepb=b.substr(pos,7);
    for(int i=1;i<=3;i++){
        sum[i]+=decode[tepa[i*2]];
        sum[i]-=decode[tepb[i*2]];
        sum[i]+=decode[tepa[i*2-1]]*16;
        sum[i]-=decode[tepb[i*2-1]]*16;

    }

    for(int i=1;i<=3;i++){
        if(sum[i]<0){
            sum[i]=0;
        }

    }
    tepre[0]='#';
    for(int i=1;i<=3;i++){
        tepre[i*2-1]=encode[sum[i]/16];
        tepre[i*2]=encode[sum[i]%16];
    }
    string re(tepre);
    return re;
}
string division1(string a,string b)
{
    a=change1(a);
    int num;
    string color;
    string::size_type pos=0;
    map<char,int> decode;
    map<int,char> encode;
    int sum[4];
    char tepre[10];
    memset(tepre,0,sizeof(tepre));
    memset(sum,0,sizeof(sum));

    num=atoi(b.c_str());
    pos=a.find('#');
    color=a.substr(pos,7);

    for(int i=0;i<=9;i++){
        char c=i+'0';
        decode[c]=i;
        encode[i]=c;
    }
    for(int i=0;i<=5;i++){
        char c='a'+i;
        decode[c]=10+i;
        encode[10+i]=c;
    }
    for(int i=1;i<=3;i++){
        sum[i]+=decode[color[i*2]];
        sum[i]+=decode[color[i*2-1]]*16;
        sum[i]=sum[i]/num;
    }
    for(int i=1;i<=3;i++)
        if(sum[i]>255)
            sum[i]=255;
    tepre[0]='#';
    for(int i=1;i<=3;i++){
        tepre[i*2-1]=encode[sum[i]/16];
        tepre[i*2]=encode[sum[i]%16];
    }
    string re(tepre);
    return re;

}
string constant(string a,string b,char c)
{
    char tepre[40];
    memset(tepre,0,sizeof(tepre));
    int num1=atoi(a.c_str());
    int num2=atoi(b.c_str());
    int num;
    if(c=='+'){
        num=num1+num2;
    }
    else if(c=='-'){
        num=num1-num2;
    }
    else if(c=='*'){
        num=num1*num2;
    }
    else if(c=='/'){
        num=num1/num2;
    }
    sprintf(tepre,"%d",num);
    string re(tepre);
    return re;
}
string calll(string a,string b,char c)
{

    int type=gettype(a,b);
    string re;
    if(type==1){
        if(c=='+')
            re=add1(a,b);
        if(c=='*'){
            re=mul1(a,b);
            }
        if(c=='/')
            re=division1(a,b);
        if(c=='-')
            re=subtract1(a,b);
    }
    else if(type ==2){
        if(c=='+')
            re=add2(a,b);
        else if(c=='-')
            re=subtract2(a,b);
        else if(c=='*')
            re=mul2(a,b);
        else if(c=='/')
            re=division2(a,b);
    }
    else if(type==3){
        re=constant(a,b,c);
    }

    return re;

}
/**
** 函数功能 ： 计算表达式，其中表达式没有括号
**/
string call(string s)
{
    string::size_type pos=0;
    while(pos<s.size()){

        if(s[pos]=='*' || s[pos]=='/'){
            string::size_type l2=pos-1,l1;
            string::size_type r1=pos+1,r2;
            ///清除空白
            while(l2>0 && (s[l2]==' '||s[l2]=='\t')){
                l2--;
            }
            while(r1<s.size() &&(s[r1]==' '||s[r1]=='\t')){
                r1++;
            }
            l1=l2;
            r2=r1;
            ///得到两边的变量
            while(l1>0 && invar(s[l1])) l1--;
            while(r2<s.size() && invar(s[r2])) r2++;
            string a=s.substr(l1,l2-l1+1);
            string b=s.substr(r1,r2-r1+1);
            string tepre=calll(a,b,s[pos]);
            tepre=" "+tepre+" ";
            s.replace(l1,r2-l1+1,tepre);
            pos=l1+tepre.size();
        }
        else
            pos++;
    }
    pos=0;
    while(pos<s.size()){
        if(s[pos]=='+' || s[pos]=='-'){
            ///防止减号和变量内部符号相混
            if(s[pos]=='-'){
                if(s[pos-1]!=' '){
                    pos++;
                    continue;
                }
            }
            string::size_type l1,l2;
            string::size_type r1,r2;
            l2=pos-1;
            r1=pos+1;
            ///清除多余的空白
            while(l2>0 && (s[l2]==' '||s[l2]=='\t')){
                l2--;
            }
            while(r1<s.size()&&(s[r1]==' '||s[r1]=='\t')){
                r1++;
            }
            r2=r1;
            l1=l2;
            while(l1>0 && invar(s[l1])) l1--;
            while(r2<s.size()&&invar(s[r2])) r2++;
            string a=s.substr(l1,l2-l1+1);
            string b=s.substr(r1,r2-r1+1);
            string tepre=calll(a,b,s[pos]);
            s.replace(l1,r2-l1+1,tepre);
            pos=l1+tepre.size();
        }
        else
            pos++;
    }
    return s;
}

string cal(string s)
{

    string::size_type pos=0;
    bool flag=false;
    while(pos<s.size()){
        if(oper.count(s[pos])){
            if(s[pos]=='/'){
                int l,r;
                l=pos-1;r=pos+1;
                while(l>0 && s[pos]==' ')
                    l--;
                while(r<s.size() && s[r]==' ')
                    r++;
               if(!(s[r]<='9'&&s[r]>='0')){
                    pos++;
                    continue;
               }

            }
            flag=1;
            break;
        }
        pos++;
    }
    ///如果没有运算符号的话就直接返回这个式子
    if(!flag){
        return s;
    }
    ///首先检查括号
    pos=0;
    while(pos<s.size()){
        if(s[pos]=='('){
            int endpos=pos;
            while(endpos<s.size() && s[endpos]!=')')
                endpos++;
            string tepre=call(s.substr(pos+1,endpos-pos-1));
            s.replace(pos,endpos-pos+1,tepre);
            pos+=tepre.size();
        }
        else
            pos++;
    }
    string re=call(s);
    return re;


}

/**
* 函数功能 ： 判断变量出现的时候起到的作用
*
*/

int varjudge(string &content,int from,int to)
{
    int assignflag=0;
    int operand=0;
    int operflag=0;
    int varflag=0;
    int pos=from;
    int midpos=pos;
    while(midpos<=to){
        if(content[midpos]==':'){
            assignflag=1;
            break;
        }
        else
            midpos++;
    }
    if(!assignflag)
        return 0;
    if(content[from]=='@')
        operand=1;
    midpos++;
    while(midpos<=to){
        if(content[midpos]=='@')
            varflag=1;
        if(oper.count(content[midpos]))
            operflag=1;
        midpos++;
    }
    if(operand && !varflag)
        return 1;
    if(!operand && varflag)
        return 3;
    if(operand && varflag)
        return 2;
    return 0;
}

void init()
{
    ///清空变量作用域
    variable.clear();
    ///清空函数作用域
    fun.clear();
    length=content.size();
    oper.insert('+');oper.insert('-');
    oper.insert('*');oper.insert('/');
    interpolation=0;

}

string rmvar(set<pss> &p,string content)
{
    int to=content.size()-1;
    int length=content.size();
    int bracketnum=0;
    int pos=0;
    string re;
    while(pos<=to){
        while(pos<length && !istag(content[pos]))
        {
            pos++;
        }
        if(content[pos]==';'){
            int endpos=pos;
            pos--;
            while(pos>=0 && !istag(content[pos]))
                pos--;
            pos++;
            while(isblank(content[pos])) pos++;
            if(varjudge(content,pos,endpos)==1 ||varjudge(content,pos,endpos)==2){
                pos=endpos+1;
                continue;
            }
            int mid=pos;
            while(mid<=endpos && content[mid]!=':')
                mid++;
            string aa=sub(content,pos,endpos);
            if(havevar(content,mid,endpos)){
                ///这里要对字符串插值进行特判
                string as=sub(content,mid+1,endpos-1);
                string t=var2val(p,content,mid+1,endpos-1);

                string tt=t;
                if(!interpolation)
                    tt=cal(t);
                else{
                    interpolation=0;
                }
                re+="\n"+sub(content,pos,mid);
                re+=tt+";";
                pos=endpos+1;
            }
            else{

                if(haveoper(content,mid,endpos)){

                    char tep[2000];
                    substring(tep,content,mid,endpos);
                    string tt(tep);
                    string t=cal(tt);
                    re+="\n"+sub(content,pos,mid-1);
                    re+=t+";";
                    pos=endpos+1;
                }
                else{

                    char tep[2000];
                    memset(tep,0,sizeof(tep));
                    substring(tep,content,pos,endpos);
                    string t(tep);
                    re+="\n";
                    re+=t;
                    pos=endpos+1;
                }
            }
        }
        else if(content[pos]=='/'){
            if(pos<length && content[pos+1]=='/'){
                ///略过行注释
                int endpos=getlend(content,pos);
                pos=endpos+1;
                continue;
            }
            else if(pos<length && content[pos+1]=='*'){
                ///保留块注释
                int endpos=anotatnend(content,pos);
                char annotation[2000];
                memset(annotation,0,sizeof(annotation));
                substring(annotation,content,pos,endpos);
                string tep(annotation);
                re+=tep;
                pos=endpos+1;
            }
            else{
                ///防止和除号混了
                pos++;
            }
        }
        else{
            pos++;
        }
    }
    return re;
}
void initvar(set<pss> &p,string s)
{
    curvar.clear();
    int pos,to;
    pos=0;
    to=s.size()-1;
    int bracketnum=0;
    while(pos<=to){
        if(s[pos]=='@' && !bracketnum){
            int endpos=getend(s,pos);
            if(varjudge(s,pos,endpos)==1){
                int mid=pos;
                while(s[mid]!=':') mid++;
                string t=s.substr(mid+1,endpos-mid-1);
                //cout<<t<<endl;
                t=cal(t);
                mid--;
                while(s[mid]==' ')
                    mid--;
                string var=s.substr(pos,mid-pos+1);
                insertvar(p,make_pair(var,t));
                insertvar(curvar,make_pair(var,t));
                pos=endpos+1;
            }
            else{
                pos=endpos+1;
            }
        }
        else if(s[pos]=='/'){
                if(s[pos+1]=='/' || s[pos+1]=='*'){
                    if(s[pos+1]=='/'){
                        int endpos=pos+1;
                        while(s[endpos]!='\n')
                            endpos++;
                        pos=endpos+1;
                    }
                    else{
                        int endpos=pos+1;
                        while(endpos<=to && (!(s[endpos]=='*' && s[endpos+1]=='/')))
                            endpos++;
                        pos=endpos+2;
                    }
                }
                else{
                    pos++;
                }
        }
        else{
            if(s[pos]=='{')
                bracketnum++;
            if(s[pos]=='}')
                bracketnum--;
            pos++;

        }

    }
    for(int times=1;times<=5;times++){
        pos=0;
        bracketnum=0;
        while(pos<=to){
            if(s[pos]=='@' && !bracketnum){
                int endpos=getend(s,pos);
                if(varjudge(s,pos,endpos)==2){
                    int teppos=pos;
                    while(s[teppos]!=':') teppos++;
                    string t=s.substr(teppos+1,endpos-teppos-1);
                    t=var2val(p,t,0,t.size()-1);
                    if(t==""){
                        pos=endpos+1;
                        continue;
                    }
                    string val=cal(t);
                    if(val==""){
                        pos=endpos+1;
                        continue;
                    }
                    teppos--;
                    while(s[teppos]==' '||s[teppos]=='\t')
                        teppos--;
                    string var=s.substr(pos,teppos-pos+1);
                    insertvar(p,make_pair(var,val));
                    insertvar(curvar,make_pair(var,val));

                    pos=endpos+1;
                }
                else
                    pos=endpos+1;
            }
            else if(s[pos]=='/'){
                if(s[pos+1]=='/' || s[pos+1]=='*'){
                    if(s[pos+1]=='/'){
                        int endpos=pos+1;
                        while(s[endpos]!='\n')
                            endpos++;
                        pos=endpos+1;
                    }
                    else{
                        int endpos=pos+1;
                        while(endpos<=to && (!(s[endpos]=='*' && s[endpos+1]=='/')))
                            endpos++;
                        pos=endpos+2;
                    }
                }
                else{
                    pos++;
                }
            }
            else{
                if(s[pos]=='{')
                    bracketnum++;
                else if(s[pos]=='}')
                    bracketnum--;
                pos++;
            }
        }
    }
    curvar.clear();

}
string findcall(set<pss> &p,string name,string para)
{

    string re;
    vector<callnode>::iterator iter=fun.end();
    iter--;
    if(fun.empty()){
        return "";
    }
    while(1){
        if((*iter).prefix==name){
            string funbody=(*iter).funbody;
            initvar(p,funbody);
            if((*iter).para==""){
                string tep=rmvar(p,funbody);
                ///还要计算吧
                re+=tep;
                break;
            }
            else{
                ///取得参数的数目
                int num1=0,num2=0;
                int pos=0;
                while(pos<para.size()){
                    if(para[pos]==',')
                        num1++;
                    pos++;
                }
                if(para!="")
                    num1++;
                pos=0;
                while(pos<(*iter).para.size()){
                    if((*iter).para[pos]==',')
                        num2++;
                    pos++;
                }
                if((*iter).para!="")
                    num2++;
                if(num1<num2){
                    string paravar;
                    int ge=1;
                    int pos1=0;
                    int length1=(*iter).para.size();
                    int length2=para.size();
                    int pos2=0;
                    while(ge<=num1){

                        while(pos1<length1){

                            if((*iter).para[pos1]=='@'){
                                int endpos=pos1+1;
                                while((*iter).para[endpos]!=':')
                                {
                                    endpos++;
                                }
                                paravar+=(*iter).para.substr(pos1,endpos-pos1+1);
                                while((*iter).para[endpos]!=','&&(*iter).para[endpos]!=')')
                                    endpos++;
                                pos1=endpos+1;
                                break;
                            }
                            else pos1++;

                        }

                        while(pos2<=length2){
                            if(para[pos2]==','||para[pos2]==')'){
                                int endpos=pos2;
                                pos2--;
                                while(para[pos2]!=',' && para[pos2]!='(')
                                        pos2--;
                                pos2++;
                                paravar+=para.substr(pos2,endpos-pos2);
                                paravar+=";\n";
                                pos2=endpos+1;
                                break;
                            }
                            else pos2++;
                        }

                        ge++;
                    }
                    while(pos1<length1){
                        if((*iter).para[pos1]==','||(*iter).para[pos1]==')')
                            paravar+=";\n";
                        else
                            paravar.push_back((*iter).para[pos1]);
                        pos1++;
                    }

                    initvar(p,paravar);
                    re=rmvar(p,funbody);
                    //cout<<re<<endl;
                    break;
                }
                else if(num1==num2){
                    string paravar;
                    int ge=1;
                    int pos1=0;
                    int length1=(*iter).para.size();
                    int length2=para.size();
                    int pos2=0;
                    while(ge<=num1){
                        while(pos1<length1){

                            if((*iter).para[pos1]=='@'){
                                int endpos=pos1+1;
                                while((*iter).para[endpos]!=':')
                                {
                                    endpos++;
                                }
                                paravar+=(*iter).para.substr(pos1,endpos-pos1+1);
                                while((*iter).para[endpos]!=','&&(*iter).para[endpos]!=')')
                                    endpos++;
                                pos1=endpos+1;
                                break;
                            }
                            else
                                pos1++;

                        }
                        while(pos2<length2){

                            if(para[pos2]==',' || para[pos2]==')'){

                                int endpos=pos2;
                                pos2--;
                                while(para[pos2]!=',' && para[pos2]!='(')
                                        pos2--;
                                pos2++;
                                paravar+=para.substr(pos2,endpos-pos2);
                                paravar+=";\n";
                                pos2=endpos+1;
                                break;
                            }
                            else{

                                pos2++;
                                }
                        }
                        ge++;
                    }
                    initvar(p,paravar);
                    re=rmvar(p,funbody);

                    break;
                }
            }
            break;
        }
        if(iter==fun.begin())
        {
            break;
        }
        else
            iter--;
    }
    return re;
}
string initmix(set<pss>&p,string body)
{


    string re;
    int pos=0;
    int flag=true;
    int to=body.size();
    while(pos<=to){
        flag=true;
        if(body[pos]=='.'){
            int endpos=pos+1;

            while(body[endpos]!=' ' && body[endpos]!=';' && body[endpos]!='(' &&body[endpos]!='{'){
                if(!invar(body[endpos])){
                    flag=false;
                }
                endpos++;
            }

            while(body[endpos]==' ')
                endpos++;
            if(body[endpos]=='{'){

                endpos=getmatch(body,endpos+1);
                pos=endpos+1;
                flag=false;
            }

            if(!flag){
                pos=endpos+1;
                continue;
            }
            string name=body.substr(pos,endpos-pos);
            while(body[endpos]==' '||body[endpos]=='\t')
                endpos++;
            if(body[endpos]!='(' &&body[endpos]!=';'){
                pos=endpos+1;
                continue;
            }
            string para;
            if(body[endpos]=='('){
                int lpos=endpos;
                while(body[endpos]!=')')
                    endpos++;
                para=body.substr(lpos,endpos-lpos+1);

                ///参数带有括号
            }
            else{
                para="";
            }
            re+=findcall(p,name,para);
            while(body[endpos]!=';')
                endpos++;
            pos=endpos+1;
        }
        else{
            pos++;
        }
    }

    return re;

}
void deal(string current,string prefix,string para,int from,int to)
{

    int bracketnum=0;
    int funnum=0;
    int pos=from;
    set<pss> var;
    set<pss> & p=var;
    queue<pro_node> pro;
    ///将当前的内容插入到函数
    fun.push_back(callnode(current,para,content.substr(from,to-from+1),1));
    if(para!="")
        return ;
    string thebody=content.substr(from,to-from+1);
    string thetail;
    if(prefix!="")
        thetail=initmix(p,thebody);
    ///与处理当前域中的变量集合

    string tepbody=content.substr(from,to-from+1);
    initvar(p,tepbody);
    ///变量处理结束
    /*//调试用
    for(set<pss>::iterator a=p.begin();a!=p.end();a++)
        cout<<(*a).first<<"%%%"<<(*a).second<<endl;
    cout<<"!!!!end!!!!!"<<endl;
    */

    variable.push_back(var);
    bracketnum=0;
    pos=from;
    string re;
    while(pos<=to){
        while(pos<length && !istag(content[pos]))
        {
            pos++;
        }
        if(content[pos]==';'){
            int endpos=pos;
            pos--;
            while(pos>=from && content[pos]!='\n' &&content[pos]!=';')
                pos--;
            pos++;
            while(isblank(content[pos])) pos++;
            if(content[pos]=='.')
            {
                pos=endpos+1;
                continue;
            }
            if(varjudge(content,pos,endpos)==1 ||varjudge(content,pos,endpos)==2){
                pos=endpos+1;
                continue;
            }
            int mid=pos;
            while(mid<=endpos && content[mid]!=':')
                mid++;
            if(havevar(content,mid,endpos)){

                ///这里要对字符串插值进行特判

                string t=var2val(p,content,mid+1,endpos-1);

                string tt=t;
                if(!interpolation)
                    tt=cal(t);
                else{
                    interpolation=0;
                }
                re+="\n"+sub(content,pos,mid);
                re+=tt+";";
                pos=endpos+1;
            }
            else{

                if(haveoper(content,mid,endpos)){

                    char tep[2000];
                    substring(tep,content,mid+1,endpos-1);
                    string tt(tep);
                    string t=cal(tt);
                    re+="\n"+sub(content,pos,mid);
                    re+=t+";";
                    pos=endpos+1;
                }
                else{

                    char tep[2000];
                    memset(tep,0,sizeof(tep));
                    substring(tep,content,pos,endpos);
                    string t(tep);
                    re+="\n";
                    re+=t;
                    pos=endpos+1;
                }
            }
            ///这里是暂时的由于担心字符串插值哪里会干扰进入死循环

        }
        else if(content[pos]=='/'){
            if(pos<length && content[pos+1]=='/'){
                ///略过行注释
                int endpos=getlend(content,pos);
                pos=endpos+1;
                continue;
            }
            else if(pos<length && content[pos+1]=='*'){
                ///保留块注释
                int endpos=anotatnend(content,pos);
                char annotation[2000];
                memset(annotation,0,sizeof(annotation));
                substring(annotation,content,pos,endpos);
                string tep(annotation);
                re+=tep;
                pos=endpos+1;
            }
            else{
                ///防止和除号混了
                pos++;
            }
        }
        else if(content[pos]=='{'){
            int endpos=getmatch(content,pos);
            if(content[pos-1]=='@'){
                ///避免字符串插值引起的误判
                pos=endpos+1;
                continue;
            }
            pss pre=getpre(content,pos);
            string cur=pre.first;

            pre.first=" "+pre.first;
            pre.first=prefix+pre.first;
            pro.push(pro_node(cur,pre.first,pre.second,pos+1,endpos-1));
            funnum++;
            pos=endpos+1;
        }
        else{
            pos++;
        }

    }

    //fun.push_back(callnode(current,para,re,1));
    /*if(re!="" || thetail!=""){
        if(prefix!="")
            fout<<prefix<<'{'<<'\n'<<re<<"\n"<<thetail<<"\n"<<'}'<<endl;
        else
            fout<<"\n"<<re<<endl;
    }
*/
    if(re!="" || thetail!=""){
        if(prefix!=""){
            fprintf(fout,"\n%s{\n%s\n%s\n}",prefix.c_str(),re.c_str(),thetail.c_str());
        }
        else{
            fprintf(fout,"\n%s",re.c_str());
        }
    }
    while(pro.size()){
        pro_node x=pro.front();
        pro.pop();
        deal(x.current,x.prefix,x.para,x.from,x.to);
    }
    ///这里应该把当前的变量作用域弹出
    variable.pop_back();
}
/**
** 函数功能 ： 去除行内注释
**/
void rmnote_inlines(string & s)
{
    string::size_type pos=0;
    string::size_type length=s.size();
    while(pos<length){
        if(s[pos]=='/'&&s[pos+1]=='*'){
            int endpos=pos+2;
            while(endpos<length &&!(s[endpos]=='*' && s[endpos+1]=='/'))
                endpos++;
            endpos++;
            int flag=0;
            if(pos==0 || s[pos-1]=='\n')
                flag=1;
            if(endpos+1==length || s[endpos+1]=='\n'){
                flag=1;
            }
            if(!flag){
                s.erase(pos,endpos-pos+1);

            }
        }
        else{
            pos++;
        }
    }
}
int main ()
{
    for(int fileid=1;fileid<=200;fileid++){
        content.clear();

        int ok=readin(fileid);
        if(!ok)
            break;
        cout<<"file num: "<<fileid<<endl;
        //rmnote_inlines(content);
        init();
        int length=content.size();
        deal("","","",0,length-1);
        //fout.close();
        fclose(fout);
    }
    return 0;
}
